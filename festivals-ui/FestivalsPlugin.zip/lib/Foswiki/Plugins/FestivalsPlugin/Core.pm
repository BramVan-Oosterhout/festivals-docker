
package Foswiki::Plugins::FestivalsPlugin::Core;

use strict;
use warnings;

use Data::Dump qw(dump);
use Time::Piece;

use Foswiki::Func ();
use Error qw(:try);
use Foswiki::Plugins::FestivalsPlugin::FestivalsAgent ();

sub new {
    my $class = shift;

    my $festivalsDir =
      $Foswiki::cfg{WorkingDir} . '/work_areas/FestivalsPlugin';
    my $initFestivalAgent = {
        domain        => $Foswiki::cfg{Plugins}{FestivalsPlugin}{Domain},
        SSL_ca_file   => $festivalsDir . '/ca.crt',
        SSL_cert_file => $festivalsDir . '/api-client.crt',
        SSL_key_file  => $festivalsDir . '/api-client.key',
        user_id       => $Foswiki::cfg{Plugins}{FestivalsPlugin}{UserId},
        password      => $Foswiki::cfg{Plugins}{FestivalsPlugin}{Password},
        api_key       => $Foswiki::cfg{Plugins}{FestivalsPlugin}{ApiKey},
        use_container_network =>
          $Foswiki::cfg{Plugins}{FestivalsPlugin}{UseContainerNetwork},
    };

    #   write_debug( dump($initFestivalAgent));
    my $this = bless( {@_}, $class );

    $this->{fa} =
      Foswiki::Plugins::FestivalsPlugin::FestivalsAgent->new(
        $initFestivalAgent);

    # $this->{doneCss} = 0;

    return $this;
}

sub GATEWAY_INFO {
    my $self = shift;

    my $fa = $self->{fa};

    my $info = $fa->get_gateway_info();

    #write_debug( dump($info) );

    return dump( $fa->get_gateway_info() );
}

sub FESTIVALS_LIST {
    my $self = shift;
    my ( $session, $params, $topic, $web, $topicObject ) = @_;
    my $fa      = $self->{fa};
    my $rawList = $fa->get_api_endpoint('/festivals')->{data};

    #write_debug( 'FESTIVALS: ', dump($rawList));
    my @festivalsList = ();

    foreach my $entry (@$rawList) {
        my %details = ();
        my $t;
        $details{id}   = $entry->{festival_id};
        $details{name} = $entry->{festival_name};
        $t = Time::Piece->strptime( $entry->{festival_start}, '%s' );
        $details{start} = $t->strftime("%A-%d-%b-%Y");
        $t = Time::Piece->strptime( $entry->{festival_end}, '%s' );
        $details{end}         = $t->strftime("%A-%d-%b-%Y");
        $details{description} = $entry->{festival_description};
        ( $details{event_count}, $details{artist_count} ) =
          _count_objects( $fa, $details{id} );
        my $f = join '~', $details{id},
          $details{name},
          $details{start},
          $details{end},
          $details{artist_count},
          $details{event_count},
          $details{description};
        push @festivalsList, $f;
    }
    return join '~~~', @festivalsList;
}

sub _count_objects {
    my ( $fa, $festivalId ) = @_;
    my $endpoint = join '', '/festivals/', $festivalId, '/events';
    my $list = $fa->get_api_endpoint($endpoint)->{data};

    #write_debug( $endpoint, dump($list) );
    return ( 0, 0 ) unless $list;

    return ( scalar @$list, scalar keys %{ _festivals_artists( $fa, $list ) } );
}

sub _festivals_artists {
    my ( $fa, $eventList ) = @_;
    my %artists = ();
    foreach my $e (@$eventList) {

        #write_debug('EVENT: ', dump($e) ); return (2,2);
        my $endpoint = join '', '/events/', $e->{event_id}, '/artist';
        my $artistList = $fa->get_api_endpoint($endpoint);

        #write_debug('ARTISTLIST: ', $endpoint, dump($artistList) );

        next unless $artistList;
        foreach my $a ( @{ $artistList->{data} } ) {

            #write_debug('ARTIST: ', dump($a) );           return( 1, 1);
            $artists{ $a->{artist_id} } = $a->{artist_name}
              unless $artists{ $a->{artist_id} };
        }
    }

    #my @keys = keys %artists;
    return \%artists;    #\@keys;
}

sub EVENTS_LIST {
    my $self = shift;
    my ( $session, $params, $topic, $web, $topicObject ) = @_;
    my $festival_id = $params->{festival_id};
    my $selectedDay = $params->{day} // 'All';
    my $fa          = $self->{fa};
    my $endpoint    = join '', '/festivals/', $festival_id, '/events';
    my $rawList     = $fa->get_api_endpoint($endpoint)->{data};
    my @eventsList  = ();

    foreach my $entry (@$rawList) {
        my %details = ();
        my $t;
        $t = Time::Piece->strptime( $entry->{event_start}, '%s' );
        next unless ( $selectedDay eq 'All' ) or ( $selectedDay eq $t->day );
        $details{day}      = $t->day;
        $details{timeslot} = $t->strftime('%I %p');
        $details{start}    = $t->strftime('%I:%m %p');
        $t = Time::Piece->strptime( $entry->{event_end}, '%s' );
        $details{end}  = $t->strftime('%I:%m %p');
        $details{name} = $entry->{event_name};
        my $l = $fa->get_api_endpoint(
            '/events/' . $entry->{event_id} . '/location' );
        $details{location} = $l->{data}[0]{location_name};
        my $a =
          $fa->get_api_endpoint( '/events/' . $entry->{event_id} . '/artist' );
        $details{artist}    = $a->{data}[0]{artist_name};
        $details{artist_id} = $a->{data}[0]{artist_id};

        my $e = join '~', $details{name},
          $details{start} . ' - ' . $details{end},
          $details{location},
          $details{artist_id};
        my $listEntry = [ $entry->{event_start}, $e ];
        push @eventsList, $listEntry;

    }
    my @sortedList = sort { $a->[0] <=> $b->[0] } @eventsList;
    my @result = ();
    foreach my $item (@sortedList) {
        push @result, $item->[1];
    }
    return join '~~~', @result;
}

sub ARTISTS_LIST {
    my $self = shift;
    my ( $session, $params, $topic, $web, $topicObject ) = @_;

#write_debug('ARTISTSLIST params: ', dump($params), "{fid}", $params->{festival_id});
    my $festivalId = $params->{festival_id};
    my $fa         = $self->{fa};
    my $endpoint   = join( '', '/festivals/', $festivalId, '/events' );
    my $eventList  = $fa->get_api_endpoint($endpoint);

    #write_debug($endpoint, dump($eventList));
    return '' unless $eventList;

    my $artistList = _festivals_artists( $fa, $eventList->{data} );
    my @list = ();
    foreach my $artistId ( keys %{$artistList} ) {
        push @list, $artistList->{$artistId} . '~' . $artistId;
    }
    return join '~~~', @list;
}

sub ARTIST_NAME {
    my $self = shift;
    my ( $session, $params, $topic, $web, $topicObject ) = @_;

    my $artistId = $params->{_DEFAULT} // $params->{artist_id} // undef;
    my $artist = _get_artist( $self->{fa}, $artistId, 'ARTIST_NAME' );
    return $artist->{artist_name}
      if ( $artist && ( ref($artist) eq 'HASH' ) );
    return $artist;
}

sub ARTIST_DESCRIPTION {
    my $self = shift;
    my ( $session, $params, $topic, $web, $topicObject ) = @_;

    my $artistId = $params->{_DEFAULT} // $params->{artist_id} // undef;
    my $artist = _get_artist( $self->{fa}, $artistId, 'ARTIST_DESCRIPTION' );

    return $artist->{artist_description}
      if ( $artist && ( ref($artist) eq 'HASH' ) );
    return $artist;
}

sub ARTIST_IMAGE {
    my $self = shift;
    my ( $session, $params, $topic, $web, $topicObject ) = @_;

    my $artistId = $params->{_DEFAULT} // $params->{artist_id} // undef;
    return "No artist_id provided for ARTIST_IMAGE\."
      unless $artistId;

    my $endpoint = '/artists/' . $artistId . '/image';
    my $images   = $self->{fa}->get_api_endpoint($endpoint);

    return $images->{data}[0]->{image_ref};

    return "$endpoint<br />" . dump($images);
}

sub ARTIST_TAGS {
    my $self = shift;
    my ( $session, $params, $topic, $web, $topicObject ) = @_;

    my $artistId = $params->{_DEFAULT} // $params->{artist_id} // undef;
    return "No artist_id provided for ARTIST_TAGS\."
      unless $artistId;

    my $endpoint = '/artists/' . $artistId . '/tags';
    my $tags     = $self->{fa}->get_api_endpoint($endpoint);
    return '' unless $tags;
    my @result = ();
    foreach my $t ( @{ $tags->{data} } ) {
        push @result, $t->{data}{tag_name};
    }
    return join '~~~', @result;

    return "$endpoint<br />" . dump($tags) . "<br />" . join '~~~', @result;
}

sub ARTIST_EVENTS {
    my $self = shift;
    my ( $session, $params, $topic, $web, $topicObject ) = @_;
    my @result     = ();
    my $fa         = $self->{fa};
    my $festivalId = $params->{festival_id} // undef;
    return "No festival_id provided for ARTIST_EVENTS\."
      unless $festivalId;
    my $artistId = $params->{_DEFAULT} // $params->{artist_id} // undef;
    return "No artist_id provided for ARTIST_EVENTS\."
      unless $artistId;
    my $endpoint  = '/festivals/' . $festivalId . '/events';
    my $eventList = $fa->get_api_endpoint($endpoint);
    return undef unless response_ok( $eventList, $endpoint );

    #write_debug( 'after checking response OK');
    my $end = 10;
    foreach my $event ( @{ $eventList->{data} } ) {
        my $endpoint     = '/events/' . $event->{event_id} . '/artist';
        my $eventsArtist = $fa->get_api_endpoint($endpoint);
        next unless $eventsArtist;
        my $a = $eventsArtist->{data}[0];

        #write_debug( ref $a, dump($a->{artist_id}));
        #next if $end--;
        #last;

        next unless $artistId == $eventsArtist->{data}[0]->{artist_id};

        #write_debug(
        #    'EVENT: ',
        #    dump( $event->{event_id} ),
        #    'EVEMTSARTIST: ',
        #    dump( $eventsArtist->{data}[0]->{artist_id} )
        #);
        my %details = ();
        my $t;
        $details{epoch} = $event->{event_start};
        $t = Time::Piece->strptime( $event->{event_start}, '%s' );
        $details{start} = $t->strftime('%I:%m %p');
        $details{day}   = $t->day;
        $t = Time::Piece->strptime( $event->{event_end}, '%s' );
        $details{end}  = $t->strftime('%I:%m %p');
        $details{name} = $event->{event_name};
        my $l = $fa->get_api_endpoint(
            '/events/' . $event->{event_id} . '/location' );
        $details{location} = $l ? $l->{data}[0]{location_name} : 'Not listed';
        $details{day} =

          push @result, join '~', $details{epoch},
          $details{name},
          $details{start} . ' - ' . $details{end},
          $details{location},
          $details{day};

    }
    my @sorted = sort @result;
    return join '~~~', @sorted;
}

sub response_ok {
    my ( $response, $endpoint ) = @_;

    #write_debug( join ' ', 'response_ok', $endpoint, dump($response) );
    return 1 if $response;

    #write_debug( 'Res[pnse valid: ', dump($response) );
    Foswiki::Func->writeEvent( 'FestivalsPlugin: ' . $endpoint,
        ' does not return data' );
    return undef;
}

sub write_debug {
    Foswiki::Func->writeEvent( join ' ', 'FestivalsPlugin: ', @_ );
}

sub _get_artist {
    my ( $fa, $artistId, $tagName ) = @_;
    return "No artist_id provided for $tagName\."
      unless $artistId;

    my $endpoint = '/artists/' . $artistId;
    my $artist   = $fa->get_api_endpoint($endpoint);
    return undef unless $artist;
    return $artist->{data}[0];
}

1;
