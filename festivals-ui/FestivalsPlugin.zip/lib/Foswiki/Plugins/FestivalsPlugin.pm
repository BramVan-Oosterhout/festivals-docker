package Foswiki::Plugins::FestivalsPlugin;

# Always use strict to enforce variable scoping
use strict;
use warnings;

use Data::Dump qw(dump);

use Foswiki::Func    ();    # The plugins API
use Foswiki::Plugins ();    # For the API version

our $VERSION = '1.00';

our $RELEASE = '04 Sep 2025';

# One line description of the module
our $SHORTDESCRIPTION  = 'UI support vars for Gestivals-App';
our $NO_PREFS_IN_TOPIC = 1;
our $core;

sub initPlugin {
    my ( $topic, $web, $user, $installWeb ) = @_;

    # check for Plugins.pm versions
    if ( $Foswiki::Plugins::VERSION < 2.3 ) {
        Foswiki::Func::writeWarning( 'Version mismatch between ',
            __PACKAGE__, ' and Plugins.pm' );
        return 0;
    }

    Foswiki::Func::registerTagHandler( 'GATEWAY_INFO',
        sub { return getCore()->GATEWAY_INFO(@_) } );
    Foswiki::Func::registerTagHandler( 'ARTISTS_LIST',
        sub { return getCore()->ARTISTS_LIST(@_) } );
    my $artist_name = \&ARTIST_NAME;
    Foswiki::Func::registerTagHandler( 'ARTIST_NAME',
        sub { return getCore()->ARTIST_NAME(@_) } );
    Foswiki::Func::registerTagHandler( 'ARTIST_DESCRIPTION',
        sub { return getCore()->ARTIST_DESCRIPTION(@_) } );
    Foswiki::Func::registerTagHandler( 'ARTIST_IMAGE',
        sub { return getCore()->ARTIST_IMAGE(@_) } );
    Foswiki::Func::registerTagHandler( 'ARTIST_TAGS',
        sub { return getCore()->ARTIST_TAGS(@_) } );
    Foswiki::Func::registerTagHandler( 'ARTIST_EVENTS',
        sub { return getCore()->ARTIST_EVENTS(@_) } );

    Foswiki::Func::registerTagHandler( 'EVENTS_LIST',
        sub { return getCore()->EVENTS_LIST(@_) } );
    Foswiki::Func::registerTagHandler( 'FESTIVALS_LIST',
        sub { return getCore()->FESTIVALS_LIST(@_) } );

    $core = undef;

    return 1;
}

sub _EXAMPLETAG {
    my ( $session, $params, $topic, $web, $topicObject ) = @_;

    # $session  - a reference to the Foswiki session object
    #             (you probably won't need it, but documented in Foswiki.pm)
    # $params=  - a reference to a Foswiki::Attrs object containing
    #             parameters.
    #             This can be used as a simple hash that maps parameter names
    #             to values, with _DEFAULT being the name for the default
    #             (unnamed) parameter.
    # $topic    - name of the topic in the query
    # $web      - name of the web in the query
    # $topicObject - a reference to a Foswiki::Meta object containing the
    #             topic the macro is being rendered in (new for foswiki 1.1.x)
    # Return: the result of processing the macro. This will replace the
    # macro call in the final text.
    # For example, %EXAMPLETAG{'hamburger' sideorder="onions"}%
    # $params->{_DEFAULT} will be 'hamburger'
    # $params->{sideorder} will be 'onions'
    return 'SESSION: ' . dump($session);
}

sub ARTIST_NAME {
    my ( $session, $params, $topic, $web, $topicObject ) = @_;
    return dump($session);
}

sub getCore {
    unless ( defined $core ) {
        require Foswiki::Plugins::FestivalsPlugin::Core;
        $core = Foswiki::Plugins::FestivalsPlugin::Core->new();
    }
    return $core;
}

1;

__END__
Foswiki - The Free and Open Source Wiki, http://foswiki.org/

Copyright (C) 2008-2013 Foswiki Contributors. Foswiki Contributors
are listed in the AUTHORS file in the root of this distribution.
NOTE: Please extend that file, not this notice.

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version. For
more details read LICENSE in the root of this distribution.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

As per the GPL, removal of this notice is prohibited.
